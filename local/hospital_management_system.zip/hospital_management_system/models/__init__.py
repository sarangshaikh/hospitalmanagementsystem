# -*- coding: utf-8 -*-
from . import out_patient
from . import in_patient
from . import prescription
from . import vaccine
from . import doctor
from . import appointment
from . import hospital_building
from . import bed_management
from . import operation_room
from . import pharmacy
from . import ward



