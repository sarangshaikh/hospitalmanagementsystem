from odoo import models, fields,api


class OutPatient(models.Model):
    _name = 'hospitalmanagement.outpatient'

    out_pat_lines=fields.One2many('hospitalmanagement.outpatientlines',
        'out_pat_id',string="Out Patient Lines")
     # out_pat_lines=fields.One2many('res.partner',related="name.child_id",string="Out Patient Lines")

    prescription_line_rel=fields.One2many('hospitalmanagement.lines.rel','outpat_prescrip_id',string="prescription rel")


    image = fields.Binary("Image", attachment=True,
      help="This field holds the image used as avatar for \
      this contact, limited to 1024x1024px",)

    name=fields.Many2one('res.partner',string="Patient Name")    

    birth_date=fields.Date(string="Date Of Birth")
    
    blood_type=fields.Selection([('a','A'),
     ('b','B'),('o','O')],string="Admission Type")
    
    rh_id=fields.Selection([('-','-'),
     ('+','+'),('notdefined','Not Defined')],string="RH")
    
    gender=fields.Selection([('male','Male'),
     ('female','Female')],string="Gender")
    
    responsible_id=fields.Many2one('res.users',string="Responsible")
    
    marital_id=fields.Selection([('single','Single'),
     ('married','Married'),('divorced','Divorced')],string="marital Status")

    
    doctor_name=fields.Many2one('hospitalmanagement.doctor',string="Doctor Name")

    description_id=fields.Char(string="Description")   
        
   
    # @api.multi
    # def data_transfer(self,value):
    #     prescrip_obj= self.env['hospitalmanagement.prescription']
    #     print(prescrip_obj.search([]))
    #     # orig_ids = prescrip_obj.search([('patient_name', '=', self.name)])
    #     # print(orig_ids)
    #     # print(patient_name)
    #     # if orig_ids:
    #     if self.name:
    #         prescrip_obj.write({
    #             'patient_name': self.name.id,
    #             'prescriptionlines_id': self._get_order_lines(self.prescription_line_rel)

    #             })



    # @api.multi
    # def _get_order_lines(self, sale):

    #     res = []
    #     for line in self.prescription_line_rel:

    #         res.append(
    #             (0, 0, self._get_new_sale_line(sale, line))
    #             )

    #         return res


    # @api.multi
    # def _get_new_sale_line(self, orig_sale, orig_sale_line):

    #     res = {
    #     'prescription_id': orig_sale_line.outpat_prescrip_id.id,
    #     'dose': orig_sale_line.new_dose,
    #     'medicine': orig_sale_line.new_name.id,
    #     'units': orig_sale_line.new_units,
    #     'days': orig_sale_line.new_days,
    #     'period': orig_sale_line.new_period,
    #     }
    #     return res









class OutPatientLines(models.Model):

    _name = 'hospitalmanagement.outpatientlines'

    out_pat_id= fields.Many2one('hospitalmanagement.outpatient',
        string="Out Patient Id")


    contact_no=fields.Integer(string="Contact No")
    address=fields.Char(string="Address")




   

    # @api.onchange('name')
    # def onchange_name(self):
    #     if self.name:
    






class Prescription_lines_rel(models.Model):
    _name='hospitalmanagement.lines.rel'
    # _inherit='hospitalmanagement.prescriptionlines'

    outpat_prescrip_id=fields.Many2one('hospitalmanagement.outpatient',string="Prescription in outpatient")

    name=fields.Char(string="Name",store=True)
    new_dose=fields.Char(string="Dose",store = True)
    new_units=fields.Char(string="Units",store=True)
    new_days=fields.Char(string="Days",store=True)
    new_period=fields.Char(string="Period",store=True)


    prescrip_name=fields.Many2one(related="outpat_prescrip_id.name", string="Prescription Patient")

    # new_name=fields.Char(related="prescription_id_rel.medicine",store=True)
    # new_dose=fields.Char(related="prescription_id_rel.dose",string="Dose",store = True)
    # new_units=fields.Char(related="prescription_id_rel.units",string="Units",store=True)
    # new_days=fields.Char(related="prescription_id_rel.days",string="Days",store=True)

    # prescription_id_rel=fields.Many2one('hospitalmanagement.prescriptionlines',string="prescription rel")












 # prescription_ext = fields.Many2many('hospitalmanagement.prescriptionlines', string="medicines",relation="prescription_outpatient_rel")



    # @api.onchange('name')
    # def onchange_name(self):
    #     prescription_obj= self.env['hospitalmanagement.prescriptionlines']
    #     prescription_obj = prescription_obj.search(
    #         [('new_name', '=', 'name'),
    #         ('new_dose', '=', self.member_id.id)]
    #         )
    #     self.book_ids = loans.mapped('book_id')

    # @api.onchange('name') 
    # def _onchange_name(self):
    #     lines =[]

    #     for val in self.bogus_values:
    #         line_item = {
    #         'new_name': val.name,
    #         'new_dose':  val.dose,
    #         'new_units': val.units,
    #         'new_days' : val.days,   
    #         'new_period':val.period,            
    #         }
    #         lines += [line_item]
    #         self.update({'prescription_line_rel': lines})

    # @api.onchange('name')
    # def _onchange_patient(self):
    #     if self.name:
    #         self.prescription_line_rel=self.prescription_lines_id.out_patient_lines

   

     # prescription_lines_id=fields.Many2many('hospitalmanagement.prescriplines',string="Prescription Lines",relation='prescription_outpatient_rel')


    # contact=field.Many2one('res.partner',related="name.child_id",string="Contacs")
    # prescription_lines_id=fields.One2many('hospitalmanagement.prescriptionlines','out_patient_lines',string="medicine")
    # Prescription=fields.out_patient_lineChar(string="Prescription")
