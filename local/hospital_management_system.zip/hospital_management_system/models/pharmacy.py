from odoo import models, fields


class Pharmacy(models.Model):
    _name = 'hospitalmanagement.pharmacy'


    name = fields.Char(string="Pharmacy Name")
    address=fields.Char(string="Address")
    phone=fields.Integer(string="Phone")
    mobile=fields.Char(string="Mobile")
    email_id=fields.Char(string="Email")
    fax=fields.Char(string="Fax")
    # prescription_id=fields.Many2one('hospitalmanagement.prescription',string="Prescription")
    # patient_name=fields.Char(string="Patient Name")
