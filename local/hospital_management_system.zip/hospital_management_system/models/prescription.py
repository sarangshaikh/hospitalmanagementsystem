from odoo import models,fields,api,_

class Prescription(models.Model):
	_name = 'hospitalmanagement.prescription'
	prescriptionlines_id=fields.One2many('hospitalmanagement.prescriptionlines','prescription_id',string="PrescriptionLines")



	name = fields.Char(string='Prescription Id', index=True,
		default=lambda self: _('New'))

	patient_name=fields.Many2one('hospitalmanagement.outpatient',string="Patient Name")

	doctor_id=fields.Many2one('hospitalmanagement.doctor',string="Doctor")

	pharmacy_id=fields.Many2one('hospitalmanagement.pharmacy',string="Pharmacy")

	prescription_date=fields.Date(string="Prescription Date")


	@api.model
	def create(self, vals):
		if vals.get('name', _('New')) == _('New'):
			vals['name'] = self.env['ir.sequence'].next_by_code('hospitalmanagement.prescription') or '/'
			return super(Prescription, self).create(vals)

			

class PrescriptionLines(models.Model):
	_name='hospitalmanagement.prescriptionlines'
	
	prescription_id=fields.Many2one('hospitalmanagement.prescription',string="Prescription Id")
	
	prescrip_patient=fields.Many2one(related="prescription_id.patient_name")
	medicine=fields.Many2one('hospitalmanagement.lines.rel',domain="[('prescrip_name','=','prescription_id.patient_name')]",string="Medicine")
	
	test=fields.Many2one('hospitalmanagement.lines.rel',string="Test")
	
	dose=fields.Char(related="test.new_dose",string="Dose")
	units=fields.Char(string="Units")
	days=fields.Integer(string="Days")
	period=fields.Date(string="Period")

	# prescription_line_rel=fields.One2many('hospitalmanagement.lines.rel','prescription_id_rel',string="prescription rel")
	# out_patient_lines=fields.Many2one('hospitalmanagement.prescription',string="Out_patient_lines")


	@api.onchange('medicine')
	def _onchange_medicine(self):
		if self.medicine:
			self.dose = self.medicine.new_name,
			self.unit = self.medicine.new_units,
			self.days = self.medicine.new_days,
			self.period = self.medicine.new_period












 	# @api.onchange('name')
  #   def onchange_name(self):
  #       if self.name:
            
  #           prescription_obj= self.env['hospitalmanagement.prescriptionlines']
  #           prescription_obj = salesorders_obj.search([('origin', '=', self.name)])
  #           prescription_obj = prescription_obj.search([])
  #           # [('new_name', '=', 'name'),
  #           # ('new_dose', '=', self.member_id.id)]
  #           # )
  #           prescription_obj.write({
  #           ('self.new_dose'='dose'),
  #           ('self.new_units'='unit'),
  #           ('self.new_days'='days'),
  #           ('self.period'='period'),
  #           })




# class SaleSite(models.Model):

#     _inherit = 'sale.order.line'



    

#     site_names = fields.Many2one('sites.customsites' , domain="[('sites_ids','=', order_partner_id)]")



#     site_cities = fields.Char(string='Site City' ,readonly= True, )



#     @api.onchange('site_names')

#     def _site_name_onchange(self):

#         if self.site_names:

#             self.site_cities = self.site_names.site_city